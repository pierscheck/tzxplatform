
TZX Platform — Frontend Demo (React + Tailwind)
-----------------------------------------------

What this package contains:
- A minimal React + Tailwind frontend prototype for the TZX Platform.
- Landing page, Dashboard demo, and Admin Reward Settings (stored in localStorage for demo).
- No backend included — suitable for Netlify static hosting (demo only).

How to run locally (requires Node.js):
1. npm install
2. npx tailwindcss -i ./src/styles.css -o ./src/tailwind.output.css --watch (optional)
3. npm run dev

Deployment to Netlify:
- Build: `npm run build`
- Deploy the dist folder to Netlify (Netlify can detect Vite projects automatically).

Notes:
- Admin settings are saved to localStorage (demo). In production, connect to your backend and secure admin routes.
- Replace demo logic with real API calls for deposits, OTP, payouts, and secure admin controls.
- Branding: TZX, navy/dark theme, soft reward wording.
