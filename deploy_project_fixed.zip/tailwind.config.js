
/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        tzxbg: '#0A1128',
        tzxcard: '#101A40',
        tzxgold: '#FFD700',
        tzxblue: '#0044CC'
      }
    }
  },
  plugins: [],
}
