
import React, { useState, useEffect } from 'react'
import Landing from './ui/Landing'
import Dashboard from './ui/Dashboard'

export default function App(){
  const [view, setView] = useState('landing') // 'landing' or 'dashboard' or 'admin'
  const [user, setUser] = useState(null)

  useEffect(()=>{
    // load demo user if any
    const u = JSON.parse(localStorage.getItem('tzx_demo_user') || 'null')
    if(u) setUser(u)
  },[])

  const loginDemo = (role='INVESTOR') => {
    const demo = { id: 'demo1', name: 'Demo User', role, autoReinvest: true, tzcBalance: 25400, rewardBalance: 45, referrals: 3 }
    localStorage.setItem('tzx_demo_user', JSON.stringify(demo))
    setUser(demo)
    setView('dashboard')
  }

  const logout = ()=>{
    localStorage.removeItem('tzx_demo_user')
    setUser(null)
    setView('landing')
  }

  return (
    <div className='min-h-screen text-white font-sans'>
      {view === 'landing' && <Landing onDemo={loginDemo} onAdmin={()=>setView('admin')} />}
      {view === 'dashboard' && <Dashboard user={user} onLogout={logout} onAdmin={()=>setView('admin')} />}
      {view === 'admin' && <Admin onBack={()=>setView(user ? 'dashboard' : 'landing')} />}
    </div>
  )
}

// simple Admin component inline (could be moved)
function Admin({ onBack }){
  const defaultConfig = {
    monthlyRewardPercent: 5,
    investorReferralPercent: 2,
    influencerThreshold: 10,
    influencerTierBonuses: { Starter:2, Builder:4, Leader:6, Ambassador:8 }
  }
  const [cfg, setCfg] = useState(()=>{
    return JSON.parse(localStorage.getItem('tzx_config') || JSON.stringify(defaultConfig))
  })
  useEffect(()=>{ localStorage.setItem('tzx_config', JSON.stringify(cfg)) },[cfg])

  return (
    <div className='p-8'>
      <button className='mb-4 px-4 py-2 bg-slate-700 rounded' onClick={onBack}>← Back</button>
      <h2 className='text-2xl font-semibold mb-4'>Admin — Reward Settings</h2>
      <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
        <div className='bg-[#101A40] p-4 rounded shadow'>
          <label className='text-sm text-slate-300'>Monthly Reward %</label>
          <input type='number' value={cfg.monthlyRewardPercent} onChange={e=>setCfg({...cfg, monthlyRewardPercent: Number(e.target.value)})} className='w-full mt-2 p-2 rounded bg-slate-800' />
        </div>
        <div className='bg-[#101A40] p-4 rounded shadow'>
          <label className='text-sm text-slate-300'>Investor one-time invite %</label>
          <input type='number' value={cfg.investorReferralPercent} onChange={e=>setCfg({...cfg, investorReferralPercent: Number(e.target.value)})} className='w-full mt-2 p-2 rounded bg-slate-800' />
        </div>
        <div className='bg-[#101A40] p-4 rounded shadow'>
          <label className='text-sm text-slate-300'>Invite threshold for influencer</label>
          <input type='number' value={cfg.influencerThreshold} onChange={e=>setCfg({...cfg, influencerThreshold: Number(e.target.value)})} className='w-full mt-2 p-2 rounded bg-slate-800' />
        </div>
        <div className='bg-[#101A40] p-4 rounded shadow'>
          <label className='text-sm text-slate-300'>Influencer tier bonuses (JSON)</label>
          <textarea value={JSON.stringify(cfg.influencerTierBonuses)} onChange={e=>{
            try{ const v = JSON.parse(e.target.value); setCfg({...cfg, influencerTierBonuses: v}) }catch(err){}
          }} className='w-full mt-2 p-2 rounded bg-slate-800 h-28' />
        </div>
      </div>
      <div className='mt-4 text-sm text-slate-400'>
        Changes are saved to localStorage (demo). In production, these values should be saved to your backend DB and protected by admin auth.
      </div>
    </div>
  )
}
