
import React, { useState, useEffect } from 'react'
export default function Dashboard({ user, onLogout, onAdmin }){
  const [u, setU] = useState(user)
  const [cfg, setCfg] = useState(()=> JSON.parse(localStorage.getItem('tzx_config') || '{"monthlyRewardPercent":5,"investorReferralPercent":2,"influencerThreshold":10}'))

  useEffect(()=>{ localStorage.setItem('tzx_config', JSON.stringify(cfg)) }, [cfg])

  const claim = ()=>{
    alert('Claim requested — in demo this simply clears rewardBalance. In production this triggers payout flow.')
    const nu = {...u, rewardBalance: 0}
    setU(nu); localStorage.setItem('tzx_demo_user', JSON.stringify(nu))
  }
  const reinvest = ()=>{
    const toTZC = (u.rewardBalance / cfg.monthlyRewardPercent) * 100 // demo conversion logic
    const nu = {...u, rewardBalance: 0, tzcBalance: Math.round(u.tzcBalance + toTZC)}
    setU(nu); localStorage.setItem('tzx_demo_user', JSON.stringify(nu))
    alert('Reinvested rewards into TZC balance (demo conversion applied).')
  }

  return (
    <div className='min-h-screen p-6' style={{background:'#0A1128'}}>
      <header className='flex items-center justify-between mb-6'>
        <div className='flex items-center gap-4'>
          <div className='w-12 h-12 rounded-lg bg-gradient-to-br from-blue-600 to-yellow-400 flex items-center justify-center font-bold'>TZX</div>
          <div>
            <h1 className='text-2xl font-semibold'>TZX Platform</h1>
            <div className='text-sm text-slate-300'>{u?.name} • {u?.role}</div>
          </div>
        </div>
        <div className='flex gap-3'>
          <button onClick={onAdmin} className='px-3 py-2 bg-slate-800 rounded'>Admin</button>
          <button onClick={onLogout} className='px-3 py-2 bg-slate-700 rounded'>Logout</button>
        </div>
      </header>

      <section className='grid grid-cols-1 md:grid-cols-3 gap-4 mb-6'>
        <div className='bg-[#101A40] p-5 rounded shadow'>
          <div className='text-xs text-slate-400'>My TZC Holdings</div>
          <div className='text-2xl font-semibold'>{u?.tzcBalance?.toLocaleString()} TZC</div>
          <div className='text-sm text-slate-400'>≈ ${(u?.tzcBalance*0.5).toFixed(2)} USD</div>
        </div>
        <div className='bg-[#101A40] p-5 rounded shadow'>
          <div className='text-xs text-slate-400'>Claimable Rewards</div>
          <div className='text-2xl font-semibold'>{u?.rewardBalance} USD</div>
          <div className='mt-4 flex gap-3'>
            <button onClick={claim} className='px-3 py-2 bg-yellow-400 text-slate-900 rounded'>Claim</button>
            <button onClick={reinvest} className='px-3 py-2 bg-blue-600 rounded'>Reinvest</button>
          </div>
          <div className='mt-2 text-xs text-slate-500'>Auto-Reinvest is enabled: {u?.autoReinvest ? 'Yes' : 'No'}</div>
        </div>
        <div className='bg-[#101A40] p-5 rounded shadow'>
          <div className='text-xs text-slate-400'>Referral & Tier</div>
          <div className='mt-2 font-semibold'>{u?.referrals} referrals</div>
          <div className='text-sm text-slate-400'>Invite link: <span className='font-mono bg-slate-800 px-2 py-1 rounded ml-2'>tzx.io/invite/demo1</span></div>
        </div>
      </section>

      <div className='grid md:grid-cols-3 gap-4'>
        <div className='md:col-span-2 bg-[#101A40] p-5 rounded shadow'>
          <h3 className='font-semibold mb-3'>Milestones & Progress</h3>
          <div className='h-40 flex items-center justify-center text-slate-400'>Milestone chart placeholder</div>
        </div>
        <aside className='space-y-4'>
          <div className='bg-[#101A40] p-4 rounded shadow'>
            <h4 className='font-semibold'>Profile & Security</h4>
            <div className='mt-2 text-sm text-slate-400'>Reinvest Preference: {u?.autoReinvest ? 'Auto' : 'Manual'}</div>
            <div className='mt-3'><button className='px-3 py-2 bg-blue-600 rounded'>Manage Settings</button></div>
          </div>
          <div className='bg-[#101A40] p-4 rounded shadow'>
            <h4 className='font-semibold'>Linked Payments</h4>
            <div className='mt-2 text-sm text-slate-400'>Mobile Money (Lipa Namba): Not linked</div>
          </div>
        </aside>
      </div>
    </div>
  )
}
