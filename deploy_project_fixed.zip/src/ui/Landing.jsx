
import React from 'react'
export default function Landing({ onDemo, onAdmin }){
  return (
    <div className='min-h-screen flex flex-col items-center justify-center px-6' style={{background: 'linear-gradient(180deg,#0A1128 0%, #08112a 100%)'}}>
      <header className='w-full max-w-5xl flex items-center justify-between py-6'>
        <div className='flex items-center gap-4'>
          <div className='w-12 h-12 rounded-lg bg-gradient-to-br from-blue-600 to-yellow-400 flex items-center justify-center font-bold'>TZX</div>
          <div>
            <h1 className='text-2xl font-semibold'>TZX Platform</h1>
            <div className='text-sm text-slate-300'>The Hidden Gem Before Sunrise</div>
          </div>
        </div>
        <nav className='text-sm text-slate-300'>
          <button onClick={onAdmin} className='mr-4'>Admin</button>
          <button className='px-3 py-2 bg-gradient-to-r from-blue-600 to-yellow-400 text-slate-900 rounded'>Join the Platform</button>
        </nav>
      </header>

      <main className='w-full max-w-5xl mt-8'>
        <div className='grid grid-cols-1 md:grid-cols-2 gap-8 items-center'>
          <div>
            <h2 className='text-4xl font-bold mb-4'>Earn, grow, and unlock new rewards through participation.</h2>
            <p className='text-slate-300 mb-6'>Join our community reward system. Participate, invite others, and recycle your bonuses to climb tiers.</p>
            <div className='flex gap-3'>
              <button onClick={()=>onDemo('INVESTOR')} className='px-4 py-3 bg-blue-600 rounded font-semibold'>Try as Investor</button>
              <button onClick={()=>onDemo('INFLUENCER')} className='px-4 py-3 bg-yellow-400 text-slate-900 rounded font-semibold'>Try as Influencer</button>
            </div>
          </div>
          <div className='bg-[#101A40] p-6 rounded shadow'>
            <div className='grid grid-cols-3 gap-4'>
              <div className='p-4 bg-slate-900 rounded text-center'>
                <div className='font-semibold mb-2'>Participate</div>
                <div className='text-xs text-slate-400'>Join activities & earn bonuses</div>
              </div>
              <div className='p-4 bg-slate-900 rounded text-center'>
                <div className='font-semibold mb-2'>Refer</div>
                <div className='text-xs text-slate-400'>Invite others and earn</div>
              </div>
              <div className='p-4 bg-slate-900 rounded text-center'>
                <div className='font-semibold mb-2'>Recycle</div>
                <div className='text-xs text-slate-400'>Reinvest to grow faster</div>
              </div>
            </div>
            <div className='mt-6 text-sm text-slate-400'>Soft language: reward/participation wording used to reduce regulatory exposure.</div>
          </div>
        </div>

        <section className='mt-12 bg-[#101A40] p-6 rounded shadow'>
          <h3 className='font-semibold mb-3'>Platform Highlights</h3>
          <ul className='grid md:grid-cols-2 gap-2 text-slate-300'>
            <li>Secure OTP Login</li>
            <li>5% Monthly Reward Rate</li>
            <li>Auto-Bonus Recycle</li>
            <li>Instant Payout Requests</li>
          </ul>
        </section>

        <footer className='mt-12 text-center text-slate-500'>
          © {new Date().getFullYear()} TZX Platform — Soft language reward system.
        </footer>
      </main>
    </div>
  )
}
